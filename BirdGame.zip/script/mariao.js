cc.Class({
    extends: cc.Component,

    properties: {
        sky: cc.Node,            //获得sky节点的Node属性
        bird: cc.Node,           //获得bird节点的Node属性
        // pipe1: cc.Node,
        // pipe2: cc.Node,
        birdSpriteFrame: {       //小鸟图片数组
            default: [],
            type: cc.SpriteFrame,
        },
        pipe: {
            default: [],
            type: cc.Node,
        },
        scoreNode: cc.Node,
        addscore: cc.Node,
        button: cc.Node,
        audio: {
            default: [],
            type: cc.AudioClip,
        },
        gameover: cc.Node,
    },
    //点击开始按钮
    onClick() {
        this.i = -3;
        cc.audioEngine.play(this.audio[1]);
        
    },
    //开始游戏
    onStartGame() {
        this.isPlaying=true;
        this.button.active=false;
        this.gameover.active=false;
    },
    // 游戏结束
    onGameOver() {
       this.isPlaying=false;
       this.button.active=true;
       this.gameover.active=true;
       this.i=0;
       this.bird.y=0;
       this.bird.angel=0;
       for(let i=0;i<5;i++)
       {
           this.pipe[i].active=false;
       };
       this.scoreNum=0;
       this.scoreNode.getComponent(cc.Label).string = this.scoreNum;
    },
    // LIFE-CYCLE CALLBACKS:
    //加载之前
    onLoad() {
        console.log("----------------onload");
    },
    //加载完成
    start() {
        //加速度  正值向下
        this.i = 0;
        this.scoreNum = 0;
        //the same (this.sky["x"]);
        //console.log(this.sky.x);
        this.isPlaying=false;
        console.log("----------------start");
        this.bird.runAction(
            cc.repeatForever(
                cc.sequence(
                    cc.callFunc(() => {
                        this.bird.getComponent(cc.Sprite).spriteFrame = this.birdSpriteFrame[0];    //获得bird节点的Sprite组件
                    }),
                    cc.delayTime(0.05),
                    cc.callFunc(() => {
                        if (this.i > 0  ) return;
                        this.bird.getComponent(cc.Sprite).spriteFrame = this.birdSpriteFrame[1];
                    }),
                    cc.delayTime(0.05),
                    cc.callFunc(() => {
                        if (this.i > 0) return;
                        this.bird.getComponent(cc.Sprite).spriteFrame = this.birdSpriteFrame[2];
                    }),
                    cc.delayTime(0.05),
                )

            )
        );
        cc.audioEngine.play(this.audio[0],true);
    },
    //每一帧
    update(dt) {
        if(this.isPlaying==false) return;
        this.sky.x -= 2;
        if (this.sky.x <= -800) {
            this.sky.x = 0;
        }
        this.i += 0.06;
        this.bird.y -= this.i;
        this.bird.angle = -this.i * 10;
        for (let i = 0; i < 5; i++) {
            this.pipe[i].x -= 2;
            if (this.pipe[i].x <= -500) {
                this.pipe[i].x = 500;
                this.pipe[i].active = true;
                this.pipe[i].y = Math.random() * 100 - 50 - 300;        //random随机数是0·1的数，但是不能取到1，只能无限接近
            }
            if ((Math.abs(this.pipe[i].x - this.bird.x) < 43) && this.pipe[i].active == true) {
                if (Math.abs(this.pipe[i].y + 300 - this.bird.y) < 78) {
                    if (this.pipe[i].x - this.bird.x > 41) {
                        this.scoreNum++;
                        this.scoreNode.getComponent(cc.Label).string = this.scoreNum;
                        cc.log("------------------+1------------------");
                        this.addscore.runAction(
                            cc.sequence(
                                cc.spawn(
                                    cc.fadeIn(0.6),
                                    cc.moveBy(1.0, 0, 60),
                                    // cc.scaleBy(1, 1.2),
                                    // cc.rotateBy(1.5, 360),                   
                                ),
                            cc.fadeOut(0.3),
                            cc.moveTo(0.1,-150,0),
                            )
                
                        );
                        cc.audioEngine.play(this.audio[2]);
                    };
                }
                else {
                    cc.log("-------------GAME  OVER-------------");
                    this.onGameOver();
                }

            }
        }
    },
});
